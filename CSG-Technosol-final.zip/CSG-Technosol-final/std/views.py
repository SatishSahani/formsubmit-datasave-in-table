from django.shortcuts import render, redirect
from django.http import JsonResponse
from std.models import Students

# Create your views here.
def home(request):
    std =Students.objects.all()
    return render(request, 'std/home.html', {'std': std})



# saving form data to database
def std_add(request):
    if request.method == 'POST':
        std_name = request.POST.get("name")
        std_email = request.POST.get("email")
        std_mobile = request.POST.get("mobile")
        std_gender =request.POST.get("gender")
        std_marital_status =request.POST.get("marital_status")
        std_education=request.POST.getlist("education")
        std_date_of_birth=request.POST.get("date_of_birth")
        std_age=request.POST.get("age")
        std_photo=request.FILES["photo"]
        std_description=request.POST.get("description")
        string = ""
        for i in std_education:
            string += i + ","
        string = string[:len(string)-1]
        # Create an object for model
        s = Students()
        s.name = std_name
        s.email = std_email
        s.mobile = std_mobile
        s.gender = std_gender
        s.marital_status = std_marital_status
        s.education = string
        s.date_of_birth = std_date_of_birth
        s.age = std_age
        s.photo = std_photo
        s.description = std_description

        # Save the object
        s.save()

        # return redirect("/std/home")
        return JsonResponse({'success': True})
        
    return render(request, 'std/add_std.html',{})


        

    