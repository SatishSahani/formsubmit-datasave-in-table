from django.db import models

class Students(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    mobile = models.CharField(max_length=10)  # Assuming mobile number length is 10
    gender = models.CharField(max_length=6, choices=[('Male', 'Male'), ('Female', 'Female')])
    marital_status = models.CharField(max_length=10, choices=[('Married', 'Married'), ('Unmarried', 'Unmarried'), ('Divorced', 'Divorced'), ('Widowed', 'Widowed')])
    education = models.CharField(max_length=20, choices=[('10th', '10th'), ('12th', '12th'), ('Graduation', 'Graduation'), ('Post Graduation', 'Post Graduation')])
    date_of_birth = models.DateField()
    age = models.IntegerField()
    photo = models.ImageField(upload_to='photos/')  # Adjust the upload path as needed
    description = models.TextField(max_length=250)

    def __str__(self):
        return self.name




